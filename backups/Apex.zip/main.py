#main.py
import argparse
import time
import os
from stable_baselines3 import PPO
from ui_display import UIDisplay
import requests
import numpy as np
from pentest_env import PentestEnv
from env_wrapper import apply_repetition_guard
def run_live_test(target):
    ui = UIDisplay()
    ui.print_header()
    ui.print_target_info(target, "LIVE")
    print("Loading trained model...")
    model_candidates = [
        "./models/ultra/ultra_model_final.zip",
        "./models/extended/extended_model_final.zip",
        "./models/simple/simple_model_final.zip",
        "./logs/extended/extended_model_final.zip",
        "./models/curriculum/curriculum_final.zip",
        "./models/curriculum/curriculum_phase_3_advanced.zip",
        "./models/stable/stable_model_final.zip",
        "./models/ppo_pentest_agent_v2_final.zip"
    ]
    model = None
    model_loaded = None
    for model_path in model_candidates:
        try:
            if os.path.exists(model_path):
                model = PPO.load(model_path)
                model_loaded = model_path
                print(f"Successfully loaded: {model_path}")
                break
        except Exception as e:
            print(f"Failed to load {model_path}: {e}")
            continue
    if not model:
        print("No suitable model found. Please train a model first with: python train.py extended")
        return
    env = PentestEnv(target=target, simulator_mode=False)
    env = apply_repetition_guard(env, max_repetitions=2, penalty=-40)
    obs, info = env.reset()
    done = False
    truncated = False
    total_reward = 0
    step = 1
    tools_used = []
    action_names = {
        0: "NMAP SCAN", 
        1: "DIRECTORY DISCOVERY", 
        2: "INTELLIGENT CRAWL",
        3: "XSS TEST", 
        4: "DEEP ENDPOINT ANALYSIS",
        5: "ADAPTIVE PAYLOAD GENERATION",
        6: "TARGET INTELLIGENCE ANALYSIS",
        7: "STOP"
    }
    print(f"Starting live test with model: {model_loaded}")
    print(f"Environment learning score: {env.learning_score:.3f}")
    while not (done or truncated) and step <= 30:
        action, _ = model.predict(obs, deterministic=True)
        action_item = action.item() if hasattr(action, 'item') else action
        action_name = action_names.get(action_item, f"ACTION_{action_item}")
        ui.print_step_header(step, action_name, 30)
        print(f"Agent Intelligence:")
        print(f"  Learning Score: {env.learning_score:.3f}")
        print(f"  Confidence Score: {env.confidence_score:.3f}")
        new_obs, reward, done, truncated, info = env.step(action_item)
        if action_item < 7:
            tools_used.append(action_name)
        ui.print_state_summary(env.current_state)
        ui.print_reward_info(reward, total_reward + reward)
        if env.current_state.get("xss_found"):
            xss_details = env.current_state.get("xss_details", {})
            ui.print_vulnerability_alert(xss_details)
        total_reward += reward
        obs = new_obs
        step += 1
        if done or truncated:
            break
        time.sleep(0.5)
    ui.print_final_report(env.current_state, total_reward, step - 1, tools_used, target)
    print(f"FINAL PERFORMANCE:")
    print(f"  Final Learning Score: {env.learning_score:.3f}")
    print(f"  Final Confidence Score: {env.confidence_score:.3f}")
    print(f"  Model Used: {model_loaded}")
    if env.current_state.get('xss_found'):
        print("  ASSESSMENT: XSS vulnerability successfully found!")
    elif env.current_state.get('params_found'):
        print("  ASSESSMENT: Parameters discovered, XSS testing attempted")
    elif env.current_state.get('dirs_found'):
        print("  ASSESSMENT: Directories found, parameter discovery attempted")
    elif env.current_state.get('http_found'):
        print("  ASSESSMENT: HTTP service detected, enumeration attempted")
    else:
        print("  ASSESSMENT: Basic reconnaissance completed")
    env.close()
def run_training():
    print("Starting training process...")
    print("This will create an optimized PPO model for penetration testing.")
    print()
    try:
        from train import extended_training
        model = extended_training()
        print("Extended training completed successfully!")
        return model
    except ImportError as e:
        print(f"Training module import error: {e}")
        print("Make sure train.py is in the current directory.")
    except Exception as e:
        print(f"Training error: {e}")
        print("Check the training logs for details.")
def test_model_performance():
    print("Testing Model Performance")
    print("=" * 40)
    models_dir = "./models/"
    logs_dir = "./logs/"
    models = []
    for directory in [models_dir, logs_dir]:
        if os.path.exists(directory):
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if file.endswith('.zip'):
                        models.append(os.path.join(root, file))
    if not models:
        print("No trained models found.")
        return
    print(f"Found {len(models)} trained models:")
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")
    latest_model = max(models, key=os.path.getctime)
    print(f"Testing latest model: {latest_model}")
    try:
        model = PPO.load(latest_model)
        print("Model loaded successfully")
        test_scenarios = [
            {"target": "simple_app", "description": "Basic web application"},
            {"target": "protected_app", "description": "Application with basic protections"},
            {"target": "complex_app", "description": "Complex application with multiple features"}
        ]
        total_success = 0
        total_tests = len(test_scenarios)
        for i, scenario in enumerate(test_scenarios, 1):
            print(f"\nTest {i}/{total_tests}: {scenario['description']}")
            env = PentestEnv(target=scenario["target"], simulator_mode=True)
            obs, _ = env.reset()
            total_reward = 0
            steps = 0
            max_steps = 25
            done = False
            truncated = False
            while not (done or truncated) and steps < max_steps:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, done, truncated, info = env.step(action)
                total_reward += reward
                steps += 1
            success = env.current_state.get('xss_found', False) or total_reward > 30
            if success:
                total_success += 1
            status = "SUCCESS" if success else "INCOMPLETE"
            print(f"  Result: {status} - {total_reward:.1f} reward in {steps} steps")
            env.close()
        success_rate = total_success / total_tests
        print(f"\nOverall Performance:")
        print(f"  Success Rate: {success_rate:.1%}")
        print(f"  Tests Passed: {total_success}/{total_tests}")
        if success_rate > 0.8:
            print("  Assessment: EXCELLENT - Model performs very well")
        elif success_rate > 0.6:
            print("  Assessment: GOOD - Model shows solid performance")
        elif success_rate > 0.4:
            print("  Assessment: FAIR - Model handles basic cases well")
        else:
            print("  Assessment: NEEDS IMPROVEMENT - Consider more training")
    except Exception as e:
        print(f"Model testing failed: {e}")
        print("Make sure the model was trained with the current environment setup")
def main():
    parser = argparse.ArgumentParser(description='AI Pentesting Agent')
    parser.add_argument('--target', type=str, help='Target URL for live testing')
    parser.add_argument('--live', action='store_true', help='Run live test against target')
    parser.add_argument('--train', action='store_true', help='Start training process')
    parser.add_argument('--test', action='store_true', help='Test model performance')
    parser.add_argument('--clear-cache', action='store_true', help='Clear application cache')
    args = parser.parse_args()
    if args.clear_cache:
        from utils import clear_cache
        clear_cache()
        return
    print("AI Pentesting Agent System")
    print("=" * 50)
    if args.test:
        test_model_performance()
        return
    if args.train:
        run_training()
        return
    if args.target and args.live:
        run_live_test(args.target)
        return
    print("Available Options:")
    print("  1. Run Live Test")
    print("  2. Start Extended Training")
    print("  3. Test Model Performance")
    print("  4. Exit")
    while True:
        choice = input("\nSelect option (1-4): ").strip()
        if choice == '1':
            target = input("Enter target URL: ").strip()
            if target:
                run_live_test(target)
            break
        elif choice == '2':
            run_training()
            break
        elif choice == '3':
            test_model_performance()
            break
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select 1-4.")
if __name__ == "__main__":
    main()