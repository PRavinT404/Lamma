import time
import threading
import sys
from datetime import datetime, timedelta
import json

class UIDisplay:
    def __init__(self):
        self.processes = {}
        self.session_start = time.time()
        self.current_step = 0
        self.total_steps = 15
        self.target_info = {}
        self.vulnerability_alerts = []
        self.lock = threading.Lock()
        
    def print_header(self):
        """Print enhanced header with better styling"""
        print("\n" + "█" * 100)
        print("██" + " " * 96 + "██")
        print("██" + "AI REINFORCEMENT LEARNING PENTESTING AGENT".center(96) + "██")
        print("██" + f"Session Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}".center(96) + "██")
        print("██" + " " * 96 + "██")
        print("█" * 100)
        
    def print_target_info(self, target, mode="LIVE"):
        """Enhanced target information display"""
        self.target_info = {"target": target, "mode": mode, "start_time": time.time()}
        
        print(f"\n┌{'─' * 98}┐")
        print(f"│ TARGET INFORMATION{' ' * 80}│")
        print(f"├{'─' * 98}┤")
        print(f"│ URL: {target:<91}│")
        print(f"│ Mode: {mode:<90}│")
        print(f"│ Agent: RL-PPO Enhanced with Dynamic Analysis{' ' * 54}│")
        print(f"└{'─' * 98}┘")
        
    def print_step_header(self, step_num, action_name, total_steps):
        """Enhanced step header with better progress visualization"""
        self.current_step = step_num
        self.total_steps = total_steps
        
        # Calculate progress
        progress = (step_num - 1) / total_steps
        progress_bar_length = 40
        filled_length = int(progress_bar_length * progress)
        
        progress_bar = "█" * filled_length + "░" * (progress_bar_length - filled_length)
        percentage = f"{progress * 100:.1f}%"
        
        # Time elapsed
        elapsed = time.time() - self.session_start
        elapsed_str = str(timedelta(seconds=int(elapsed)))
        
        print(f"\n{'─' * 100}")
        print(f"🤖 AI STEP {step_num:02d}/{total_steps:02d}: {action_name:<30} │ Progress: [{progress_bar}] {percentage}")
        print(f"{'─' * 100}")
        print(f"Session Time: {elapsed_str:<20} │ Current Phase: DYNAMIC ANALYSIS")
        
    def start_tool_execution(self, tool_name, estimated_duration=None):
        """Start a tool execution with dynamic progress"""
        process_id = tool_name.lower().replace(" ", "_")
        
        with self.lock:
            self.processes[process_id] = {
                "name": tool_name,
                "start_time": time.time(),
                "estimated_duration": estimated_duration or 30,
                "status": "running",
                "details": [],
                "progress": 0.0,
                "thread": None
            }
        
        # Start progress animation in separate thread
        progress_thread = threading.Thread(target=self._animate_progress, args=(process_id,))
        progress_thread.daemon = True
        progress_thread.start()
        
        self.processes[process_id]["thread"] = progress_thread
        
    def update_tool_progress(self, tool_name, progress, detail=None):
        """Update tool progress and detail"""
        process_id = tool_name.lower().replace(" ", "_")
        
        with self.lock:
            if process_id in self.processes:
                self.processes[process_id]["progress"] = progress
                if detail:
                    self.processes[process_id]["details"].append(detail)
                    
    def complete_tool_execution(self, tool_name, success, results=None):
        """Complete tool execution"""
        process_id = tool_name.lower().replace(" ", "_")
        
        with self.lock:
            if process_id in self.processes:
                self.processes[process_id]["status"] = "success" if success else "failed"
                self.processes[process_id]["progress"] = 1.0
                self.processes[process_id]["end_time"] = time.time()
                self.processes[process_id]["results"] = results
                
                # Print final status
                self._print_tool_status(process_id, final=True)

    def _animate_progress(self, process_id):
        """Animate progress indicator for running tool"""
        spinner_chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        spinner_index = 0
        
        while True:
            with self.lock:
                if process_id not in self.processes or self.processes[process_id]["status"] != "running":
                    break
                    
                process = self.processes[process_id]
                elapsed = time.time() - process["start_time"]
                estimated = process["estimated_duration"]
                progress = min(elapsed / estimated, 0.95)  # Cap at 95% until completion
                
                # Update progress
                self.processes[process_id]["progress"] = progress
                
                # Print animated status
                self._print_tool_status(process_id, spinner_chars[spinner_index % len(spinner_chars)])
                
            spinner_index += 1
            time.sleep(0.2)

    def _print_tool_status(self, process_id, spinner_char=None, final=False):
        """Print tool status with progress animation"""
        if process_id not in self.processes:
            return
            
        process = self.processes[process_id]
        name = process["name"]
        status = process["status"]
        progress = process["progress"]
        elapsed = time.time() - process["start_time"]
        
        # Clear line and move cursor up
        if not final:
            print(f"\r\033[K", end="")
        
        # Status indicator
        if status == "running":
            status_icon = spinner_char if spinner_char else "🔄"
            status_text = "RUNNING"
            color_code = "\033[33m"  # Yellow
        elif status == "success":
            status_icon = "✅"
            status_text = "SUCCESS"
            color_code = "\033[32m"  # Green
        else:
            status_icon = "❌"
            status_text = "FAILED"
            color_code = "\033[31m"  # Red
        
        # Progress bar
        bar_length = 20
        filled_length = int(bar_length * progress)
        bar = "█" * filled_length + "░" * (bar_length - filled_length)
        percentage = f"{progress * 100:.0f}%"
        
        # Time display
        time_str = f"{elapsed:.1f}s"
        if "estimated_duration" in process and status == "running":
            eta = max(0, process["estimated_duration"] - elapsed)
            time_str += f" (ETA: {eta:.0f}s)"
        
        # Build status line
        status_line = f"{color_code}{status_icon} {name:<25}{status_text:<10}[{bar}] {percentage:<4} {time_str}\033[0m"
        
        if final:
            print(status_line)
            
            # Print latest details if any
            if process.get("details"):
                latest_detail = process["details"][-1]
                print(f"   └─ {latest_detail}")
                
            # Print results summary if available
            if process.get("results"):
                self._print_results_summary(name, process["results"])
        else:
            print(status_line, end="", flush=True)
            
            # Print latest detail on new line if available
            if process.get("details"):
                latest_detail = process["details"][-1]
                print(f"\n   └─ {latest_detail}", end="", flush=True)
                print(f"\r\033[A", end="")  # Move cursor back up

    def _print_results_summary(self, tool_name, results):
        """Print summary of tool results"""
        if not results:
            return
            
        if tool_name.upper() == "NMAP SCAN":
            ports = results.get("open_ports", [])
            if ports:
                print(f"   └─ Found {len(ports)} open ports: {', '.join(str(p['port']) for p in ports[:3])}")
                
        elif tool_name.upper() == "DIRECTORY DISCOVERY":
            dirs = results.get("found_directories", [])
            if dirs:
                print(f"   └─ Found {len(dirs)} directories: {', '.join(dirs[:3])}")
                
        elif tool_name.upper() == "CRAWL & ANALYZE":
            urls = results.get("injectable_urls", [])
            if urls:
                total_params = sum(len(url.get("params", [])) for url in urls)
                print(f"   └─ Found {total_params} testable parameters across {len(urls)} endpoints")
                
        elif tool_name.upper() == "XSS TEST":
            if results.get("vulnerability"):
                payload = results.get("payload", "")[:50]
                print(f"   └─ VULNERABILITY FOUND! Payload: {payload}...")
            else:
                tests = results.get("total_tests", 0)
                print(f"   └─ Tested {tests} payloads, no successful execution")

    def print_vulnerability_alert(self, vuln_data):
        """Print vulnerability alert with enhanced styling"""
        print(f"\n{'🚨' * 20}")
        print("🚨               VULNERABILITY DETECTED!               🚨")
        print(f"{'🚨' * 20}")
        
        vuln_type = vuln_data.get("vulnerability", "Unknown")
        parameter = vuln_data.get("parameter", "unknown")
        payload = vuln_data.get("payload", "")[:100]
        confidence = vuln_data.get("confidence", "medium")
        
        print(f"┌─ Type: {vuln_type}")
        print(f"├─ Parameter: {parameter}")
        print(f"├─ Confidence: {confidence.upper()}")
        print(f"├─ Payload: {payload}")
        if len(payload) >= 100:
            print("├─         ...")
        print(f"└─ Impact: Script execution in user's browser")
        
        # Add to vulnerability list
        self.vulnerability_alerts.append({
            "timestamp": time.time(),
            "type": vuln_type,
            "parameter": parameter,
            "confidence": confidence
        })
        
    def print_state_summary(self, state):
        """Print current state summary with visual indicators"""
        indicators = []
        
        if state.get('http_found'):
            indicators.append("HTTP✓")
        if state.get('dirs_found'):
            indicators.append("DIRS✓")  
        if state.get('params_found'):
            indicators.append("PARAMS✓")
        if state.get('xss_found'):
            indicators.append("XSS🚨")
        if state.get('csrf_protected'):
            indicators.append("CSRF🛡")
        if state.get('waf_detected'):
            indicators.append("WAF🔒")
            
        if indicators:
            print(f"\n📊 Agent State: {' | '.join(indicators)}")
        else:
            print(f"\n📊 Agent State: INITIALIZING...")

    def print_reward_info(self, step_reward, total_reward):
        """Print reward information with visual styling"""
        # Determine reward color
        if step_reward > 50:
            reward_color = "\033[32m"  # Green for high positive
        elif step_reward > 0:
            reward_color = "\033[33m"  # Yellow for low positive  
        elif step_reward > -25:
            reward_color = "\033[93m"  # Light yellow for small negative
        else:
            reward_color = "\033[31m"  # Red for large negative
            
        print(f"\n🎯 Reward: {reward_color}{step_reward:+.1f}\033[0m | Total: {total_reward:.1f}")

    def print_final_report(self, final_state, total_reward, steps_taken, tools_used, target):
        """Print comprehensive final report"""
        session_time = time.time() - self.session_start
        
        print(f"\n{'=' * 100}")
        print("                         AI RL PENTESTING AGENT REPORT")
        print(f"{'=' * 100}")
        
        print(f"\nTarget: {target}")
        print(f"Session Duration: {str(timedelta(seconds=int(session_time)))}")
        print(f"Steps Taken: {steps_taken}")
        print(f"Tools Used: {', '.join(tools_used)}")
        print(f"Total Reward: {total_reward:.1f}")
        
        print(f"\nRESULTS:")
        print("-" * 40)
        
        # Check for vulnerabilities
        if self.vulnerability_alerts:
            print("🎯 VULNERABILITIES FOUND:")
            for i, vuln in enumerate(self.vulnerability_alerts, 1):
                print(f"  {i}. {vuln['type']} in parameter '{vuln['parameter']}' (confidence: {vuln['confidence']})")
        elif final_state.get('params_found'):
            print("🔋 Exploration complete (no confirmed vulnerabilities)")
        elif final_state.get('dirs_found'):
            print("📁 Directory enumeration complete (no injection points found)")
        elif final_state.get('http_found'):
            print("🌐 HTTP service detected (limited attack surface)")
        else:
            print("❌ No significant findings")
        
        # Summary stats
        print(f"\nSUMMARY:")
        open_ports = len(final_state.get('nmap_details', {}).get('open_ports', []))
        directories = len(final_state.get('gobuster_details', {}).get('found_directories', []))
        parameters = final_state.get('param_count', 0)
        
        if open_ports > 0:
            print(f"• Open ports: {open_ports}")
        if directories > 0:
            print(f"• Directories: {directories}")
        if parameters > 0:
            print(f"• Injection points: {parameters}")
            
        # Performance analysis
        print(f"\nPERFORMANCE ANALYSIS:")
        efficiency_score = self._calculate_efficiency_score(steps_taken, total_reward, tools_used)
        print(f"• Efficiency Score: {efficiency_score:.1f}/100")
        print(f"• Average Reward per Step: {total_reward/max(steps_taken,1):.1f}")
        print(f"• Tool Diversity: {len(set(tools_used))}/5 unique tools used")
        
        if efficiency_score < 50:
            print(f"• Recommendation: Consider training with more diverse scenarios")
        elif efficiency_score > 80:
            print(f"• Recommendation: Agent shows strong performance patterns")
        
        print(f"{'=' * 100}")

    def _calculate_efficiency_score(self, steps, reward, tools_used):
        """Calculate efficiency score based on performance metrics"""
        base_score = 50
        
        # Reward efficiency (higher reward per step is better)
        reward_per_step = reward / max(steps, 1)
        if reward_per_step > 10:
            base_score += 30
        elif reward_per_step > 0:
            base_score += 15
        elif reward_per_step > -10:
            base_score += 0
        else:
            base_score -= 20
            
        # Step efficiency (fewer steps is better if reward is positive)
        if reward > 0:
            if steps <= 8:
                base_score += 20
            elif steps <= 12:
                base_score += 10
            else:
                base_score -= 10
                
        # Tool diversity (using different tools appropriately)
        unique_tools = len(set(tools_used))
        if unique_tools >= 4:
            base_score += 10
        elif unique_tools >= 3:
            base_score += 5
            
        return max(0, min(100, base_score))
    
    def print_tool_status(self, tool_name, status, detail=None):
        # AI Status Panel
        # Note: The 'Panel' object and 'ai_status' variable are not defined in the current file context.
        # To use this, you would need to import 'Panel' from 'rich' and ensure 'ai_status' is passed or accessible.
        # This block is inserted as requested, but further modifications to the file's imports and method calls
        # would be necessary for it to function correctly.
        ai_status_panel = Panel(
            f"[bold cyan]Confidence Score:[/bold cyan] {ai_status.get('confidence_score', 0.0):.2f}\n"
            f"[bold cyan]Learning Score:[/bold cyan] {ai_status.get('learning_score', 0.0):.2f}\n"
            f"[bold cyan]Current State:[/bold cyan] {ai_status.get('current_state', 'N/A')}\n"
            f"[bold cyan]Executed Tools:[/bold cyan] {ai_status.get('executed_tools', 'N/A')}",
            title="[bold green]AI Status[/bold green]",
            border_style="green"
        )

        """Print tool status in enhanced format"""
        if status == "running":
            self.start_tool_execution(tool_name)
        elif status == "success":
            self.complete_tool_execution(tool_name, True)
        elif status == "failed":
            self.complete_tool_execution(tool_name, False)
        elif status == "warning":
            print(f"⚠️ {tool_name.upper()}: WARNING")
            if detail:
                print(f"   └─ {detail}")

