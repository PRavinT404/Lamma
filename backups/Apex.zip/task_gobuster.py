#task_gobuster.py
# PURPOSE: Enhanced Gobuster implementation with proper syntax

import subprocess
import os
from ai_core import run_command, ask_ollama
import json

def execute_gobuster_scan(target_url, simulator_mode=True):
    print(f"--- Starting Gobuster Task for URL: {target_url} ---")
    
    # Ensure URL starts with http:// or https://
    if not target_url.startswith(('http://', 'https://')):
        target_url = f"http://{target_url}"
    
    gobuster_output = None
    if simulator_mode:
        print("ENVIRONMENT: Gobuster in Simulator Mode. Reading from file...")
        try:
            with open("gobuster_scan.txt", "r") as f:
                gobuster_output = f.read()
        except FileNotFoundError:
            print("Warning: gobuster_scan.txt not found. Creating simulated results.")
            return {
                "found_directories": [
                    "/admin", "/login", "/test", "/backup", "/config",
                    "/api", "/uploads", "/images", "/js", "/css"
                ]
            }
    else:
        try:
            # Command to run Gobuster
            command = [
                "gobuster", "dir",
                "-u", target_url,
                "-w", "/usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt",
                "-t", "50",
                "--no-error",
                "-q",
                "-o", "gobuster_scan.txt"
            ]

            # Execute the command
            subprocess.run(command, check=True, capture_output=True, text=True)

            # Parse the output file
            with open("gobuster_scan.txt", "r") as f:
                results = [line.strip() for line in f.readlines()]  # Fixed syntax error
            
            return {"found_directories": results}
        except FileNotFoundError:
            print("Gobuster command not found. Please make sure it is installed and in your PATH.")
            return None
        except subprocess.CalledProcessError as e:
            # If Gobuster returns a non-zero exit code, but we have results, we can still use them
            if os.path.exists("gobuster_scan.txt"):
                with open("gobuster_scan.txt", "r") as f:
                    results = [line.strip() for line in f.readlines()]  # Fixed syntax error
                if results:
                    return {"found_directories": results}
            print(f"Error executing Gobuster: {e.stderr}")
            return None
    
    # Parse simulated output
    if gobuster_output:
        lines = gobuster_output.strip().split('\n')
        directories = [line.strip() for line in lines if line.strip()]
        return {"found_directories": directories}
    
    return None