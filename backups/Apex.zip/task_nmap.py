import subprocess
import json
import re
import socket
from urllib.parse import urlparse
from ai_core import ask_ollama_advanced, run_command

def execute_nmap_scan(target, simulator_mode=True):
    """
    Enhanced Nmap scan with realistic port detection and service analysis
    """
    print(f"🔍 Advanced Nmap Scan: {target}")
    
    # Parse target to extract host/IP
    if target.startswith(('http://', 'https://')):
        parsed_url = urlparse(target)
        host = parsed_url.hostname
        port_hint = parsed_url.port or (443 if parsed_url.scheme == 'https' else 80)
    else:
        host = target.split(':')[0] if ':' in target else target
        port_hint = None
    
    if not host:
        print("❌ Could not extract valid host from target")
        return None
    
    if simulator_mode:
        print("🤖 SIMULATOR MODE: Generating realistic scan results...")
        return generate_realistic_nmap_results(host, port_hint)
    else:
        return perform_live_nmap_scan(host, port_hint)

def perform_live_nmap_scan(host, port_hint=None):
    """Perform actual nmap scan with comprehensive options"""
    
    # Basic connectivity check first
    try:
        socket.gethostbyname(host)
    except socket.gaierror:
        print(f"❌ Cannot resolve hostname: {host}")
        return None
    
    # Build nmap command with realistic options
    nmap_command = [
        'nmap', 
        '-sV',           # Service version detection
        '-sC',           # Default script scan
        '-O',            # OS detection (requires sudo)
        '--script=http-enum,http-methods,http-robots.txt',  # HTTP-specific scripts
        '-T4',           # Aggressive timing
        '--max-retries=2',
        '--host-timeout=300',
        host
    ]
    
    # Smart port selection
    if port_hint:
        nmap_command.extend(['-p', f"{port_hint},22,80,443,8080,8443,3000,5000"])
    else:
        nmap_command.extend(['-p', '1-10000'])  # Comprehensive scan
    
    print(f"🚀 Running: {' '.join(nmap_command)}")
    
    try:
        nmap_output = run_command(nmap_command, timeout=300)
    except FileNotFoundError:
        print("Nmap command not found. Please make sure it is installed and in your PATH.")
        nmap_output = None
    except Exception as e:
        print(f"❌ Nmap scan failed: {e}")
        nmap_output = None
    
    if not nmap_output:
        print("⚠️ No nmap output received, falling back to basic scan")
        return perform_basic_scan(host, port_hint)
    
    return parse_nmap_output(nmap_output, host)

def perform_basic_scan(host, port_hint):
    """Fallback basic connectivity scan"""
    
    common_ports = [22, 80, 443, 8080, 8443, 3000, 5000, 8000]
    if port_hint and port_hint not in common_ports:
        common_ports.insert(0, port_hint)
    
    open_ports = []
    for port in common_ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()
            
            if result == 0:
                service = get_service_name(port)
                open_ports.append({
                    "port": port,
                    "protocol": "tcp",
                    "service": service,
                    "version": "Unknown",
                    "state": "open",
                    "banner": ""
                })
                print(f"✅ Port {port}/{service} is open")
        except Exception as e:
            continue
    
    web_services = any(p["port"] in [80, 443, 8080, 8443, 3000, 5000, 8000] for p in open_ports)
    
    return {
        "open_ports": open_ports,
        "os_detection": "Unknown",
        "web_services": web_services,
        "vulnerabilities": [],
        "attack_recommendations": [],
        "target_assessment": f"Basic scan found {len(open_ports)} open ports"
    }

def get_service_name(port):
    """Map common ports to service names"""
    port_map = {
        22: "ssh", 80: "http", 443: "https", 8080: "http-proxy",
        8443: "https-alt", 3000: "http-dev", 5000: "http-dev",
        8000: "http-alt", 3306: "mysql", 5432: "postgresql",
        6379: "redis", 27017: "mongodb", 21: "ftp", 25: "smtp"
    }
    return port_map.get(port, "unknown")

def parse_nmap_output(nmap_output, host):
    """Parse nmap output with AI assistance"""
    
    # Basic parsing first
    basic_results = parse_nmap_basic(nmap_output)
    
    # Enhanced AI analysis
    analysis_prompt = """Analyze this nmap scan output and extract detailed information:

    1. All open ports with accurate service identification
    2. Service versions and potential vulnerabilities
    3. Operating system detection results
    4. Security implications and attack recommendations
    5. Focus on web services for further testing

    Respond with JSON in this exact format:
    {
        "open_ports": [
            {
                "port": 80,
                "protocol": "tcp", 
                "service": "http",
                "version": "Apache httpd 2.4.41",
                "state": "open",
                "banner": "Server: Apache/2.4.41 (Ubuntu)"
            }
        ],
        "os_detection": "Ubuntu Linux 20.04",
        "web_services": true,
        "vulnerabilities": ["Apache 2.4.41 - potential CVE-2021-41773"],
        "attack_recommendations": ["Web application testing", "Directory enumeration"],
        "target_assessment": "Web server identified - suitable for web app testing"
    }"""
    
    ai_results = ask_ollama_advanced(
        analysis_prompt,
        nmap_output,
        analysis_type="technology"
    )
    
    # Combine basic and AI results
    if ai_results and ai_results.get("open_ports"):
        return ai_results
    else:
        print("⚠️ AI analysis failed, using basic parsing")
        return basic_results

def parse_nmap_basic(nmap_output):
    """Enhanced basic nmap output parsing"""
    
    ports = []
    lines = nmap_output.split('\n')
    os_info = "Unknown"
    
    for line in lines:
        # Parse port lines
        port_match = re.match(r'(\d+)/(tcp|udp)\s+(\w+)\s+(\S+)(?:\s+(.+))?', line.strip())
        if port_match:
            port_num = int(port_match.group(1))
            protocol = port_match.group(2)
            state = port_match.group(3)
            service = port_match.group(4)
            version_info = port_match.group(5) or ""
            
            if state == "open":
                ports.append({
                    "port": port_num,
                    "protocol": protocol,
                    "service": service,
                    "version": version_info.strip(),
                    "state": state,
                    "banner": version_info.strip()
                })
        
        # Parse OS detection
        if "OS details:" in line:
            os_info = line.split("OS details:")[-1].strip()
        elif "Running:" in line:
            os_info = line.split("Running:")[-1].strip()
    
    # Identify web services
    web_ports = [80, 443, 8080, 8443, 3000, 5000, 8000]
    has_web = any(
        p["port"] in web_ports or "http" in p["service"].lower() 
        for p in ports
    )
    
    return {
        "open_ports": ports,
        "os_detection": os_info,
        "web_services": has_web,
        "vulnerabilities": [],
        "attack_recommendations": ["Port enumeration", "Service fingerprinting"],
        "target_assessment": f"Found {len(ports)} open ports, web services: {'Yes' if has_web else 'No'}"
    }

def generate_realistic_nmap_results(host, port_hint=None):
    """Generate realistic nmap results for simulation"""
    
    # Determine what ports should be open based on target
    open_ports = []
    
    # Always include SSH (common on servers)
    open_ports.append({
        "port": 22,
        "protocol": "tcp",
        "service": "ssh",
        "version": "OpenSSH 8.2p1 Ubuntu 4ubuntu0.5",
        "state": "open",
        "banner": "SSH-2.0-OpenSSH_8.2p1"
    })
    
    # Add web service based on hint or default
    if port_hint:
        service_name = "https" if port_hint == 443 else "http"
        open_ports.append({
            "port": port_hint,
            "protocol": "tcp",
            "service": service_name,
            "version": "nginx 1.18.0",
            "state": "open",
            "banner": f"Server: nginx/1.18.0"
        })
    else:
        # Default HTTP
        open_ports.append({
            "port": 80,
            "protocol": "tcp", 
            "service": "http",
            "version": "Apache httpd 2.4.41",
            "state": "open",
            "banner": "Server: Apache/2.4.41 (Ubuntu)"
        })
    
    # Sometimes add additional services
    import random
    if random.random() > 0.5:  # 50% chance
        additional_services = [
            {"port": 3306, "service": "mysql", "version": "MySQL 8.0.28"},
            {"port": 8080, "service": "http-proxy", "version": "Tomcat 9.0"},
            {"port": 5432, "service": "postgresql", "version": "PostgreSQL 13.7"}
        ]
        
        selected = random.choice(additional_services)
        open_ports.append({
            "port": selected["port"],
            "protocol": "tcp",
            "service": selected["service"],
            "version": selected["version"],
            "state": "open",
            "banner": ""
        })
    
    web_services = any(p["port"] in [80, 443, 8080, 8443, 3000, 5000] for p in open_ports)
    
    vulnerabilities = []
    attack_recommendations = []
    
    if web_services:
        attack_recommendations.extend([
            "Web application security testing",
            "Directory and file enumeration", 
            "HTTP methods testing",
            "SSL/TLS configuration analysis"
        ])
        
        # Add some realistic vulnerabilities
        if random.random() > 0.7:  # 30% chance
            vulnerabilities.append("Potential outdated web server version")
    
    return {
        "open_ports": open_ports,
        "os_detection": "Ubuntu 20.04.4 LTS",
        "web_services": web_services,
        "vulnerabilities": vulnerabilities,
        "attack_recommendations": attack_recommendations,
        "target_assessment": f"Server with {len(open_ports)} services - {'Web testing ready' if web_services else 'Limited web services'}"
    }

# Backward compatibility
def nmap_scan(target):
    return execute_nmap_scan(target, simulator_mode=False)