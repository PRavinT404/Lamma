#train.py
import os
import numpy as np
import torch
import torch.nn as nn
import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.utils import set_random_seed
from pentest_env import PentestEnv
import json
import time
import sys
class GymnasiumCompatibilityWrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.env = env
    def reset(self, seed=None, options=None):
        if seed is not None:
            np.random.seed(seed)
        result = self.env.reset(seed=seed, options=options)
        if isinstance(result, tuple) and len(result) == 2:
            return result
        elif isinstance(result, np.ndarray):
            return result, {}
        else:
            obs, info = result if isinstance(result, tuple) else (result, {})
            return obs, info
    def step(self, action):
        result = self.env.step(action)
        if len(result) == 5:
            return result
        elif len(result) == 4:
            obs, reward, done, info = result
            terminated = done and not info.get('TimeLimit.truncated', False)
            truncated = done and info.get('TimeLimit.truncated', False)
            return obs, reward, terminated, truncated, info
        else:
            raise ValueError(f"Unexpected step result length: {len(result)}")
class SimpleCallback(BaseCallback):
    def __init__(self, verbose=0):
        super().__init__(verbose)
        self.episode_rewards = []
        self.episode_lengths = []
        self.total_episodes = 0
        self.vulnerability_count = 0
        self.success_count = 0
        self.invalid_action_count = 0
    def _on_step(self) -> bool:
        for env_idx in range(self.training_env.num_envs):
            if self.locals.get('dones')[env_idx]:
                self.total_episodes += 1
                info = self.locals.get('infos')[env_idx]
                if info and 'episode' in info:
                    episode_reward = info['episode']['r']
                    episode_length = info['episode']['l']
                    self.episode_rewards.append(episode_reward)
                    self.episode_lengths.append(episode_length)
                    if episode_reward > 25:
                        self.vulnerability_count += 1
                        self.success_count += 1
                if info.get('invalid_action'):
                    self.invalid_action_count += 1
                if self.total_episodes % 100 == 0:
                    self._log_progress()
        return True
    def _log_progress(self):
        if len(self.episode_rewards) >= 25:
            recent_rewards = self.episode_rewards[-25:]
            avg_reward = np.mean(recent_rewards)
            avg_length = np.mean(self.episode_lengths[-25:])
            success_rate = self.success_count / max(self.total_episodes, 1)
            print(f"\nProgress Report - Episode {self.total_episodes}:")
            print(f"  Average Reward: {avg_reward:.2f}")
            print(f"  Average Length: {avg_length:.1f}")
            print(f"  Success Rate: {success_rate:.2%}")
            print(f"  Vulnerabilities Found: {self.vulnerability_count}")
            print(f"  Invalid Actions: {self.invalid_action_count}")
class RewardWrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.step_count = 0
    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.step_count += 1
        if info.get('invalid_action'):
            reward = max(reward, -2.0)
        else:
            reward = max(reward, -5.0)
        reward = min(reward, 50.0)
        if self.step_count > 20:
            truncated = True
            if reward < 0:
                reward = max(reward, -1.0)
        return obs, reward, terminated, truncated, info
    def reset(self, **kwargs):
        self.step_count = 0
        return self.env.reset(**kwargs)
class UltraRewardWrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.step_count = 0
        self.consecutive_invalid = 0
        self.efficiency_bonus = 0
    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.step_count += 1
        if info.get('invalid_action'):
            self.consecutive_invalid += 1
            reward = -0.5 * self.consecutive_invalid
        else:
            self.consecutive_invalid = 0
            if reward > 0:
                reward *= 1.5
                if self.step_count <= 6:
                    reward *= 1.3
        current_state = info.get('current_state', {})
        if current_state.get('xss_found') and self.step_count <= 5:
            reward += 15.0
        elif current_state.get('params_found') and self.step_count <= 4:
            reward += 5.0
        reward = max(reward, -15.0)
        reward = min(reward, 100.0)
        if self.step_count > 15:
            truncated = True
            if current_state.get('xss_found'):
                reward += 10.0
            elif current_state.get('params_found'):
                reward += 3.0
        return obs, reward, terminated, truncated, info
    def reset(self, **kwargs):
        self.step_count = 0
        self.consecutive_invalid = 0
        self.efficiency_bonus = 0
        return self.env.reset(**kwargs)
def create_ultra_environment():
    def _init():
        env = PentestEnv(target="ultra_training", simulator_mode=True)
        env = GymnasiumCompatibilityWrapper(env)
        env = UltraRewardWrapper(env)
        log_path = f"./logs/ultra/{time.strftime('%Y-%m-%d_%H-%M-%S')}/"
        os.makedirs(log_path, exist_ok=True)
        return Monitor(env, log_path)
    return _init
def create_training_environment():
    def _init():
        env = PentestEnv(target="training_target", simulator_mode=True)
        env = GymnasiumCompatibilityWrapper(env)
        env = RewardWrapper(env)
        log_path = f"./logs/simple/{time.strftime('%Y-%m-%d_%H-%M-%S')}/"
        os.makedirs(log_path, exist_ok=True)
        return Monitor(env, log_path)
    return _init
def simple_training():
    print("Simple PPO Training for Pentesting Agent")
    print("=" * 50)
    set_random_seed(42)
    torch.manual_seed(42)
    np.random.seed(42)
    env = DummyVecEnv([create_training_environment()])
    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        learning_rate=3e-4,
        n_steps=256,
        batch_size=32,
        n_epochs=4,
        gamma=0.95,
        gae_lambda=0.9,
        clip_range=0.2,
        ent_coef=0.01,
        vf_coef=0.5,
        max_grad_norm=0.5,
        policy_kwargs=dict(
            net_arch=[64, 64],
            activation_fn=nn.ReLU
        ),
        tensorboard_log="./logs/simple/",
        device='cpu'
    )
    callback = SimpleCallback(verbose=1)
    models_dir = "./models/simple/"
    os.makedirs(models_dir, exist_ok=True)
    print("Starting simple training...")
    try:
        model.learn(
            total_timesteps=25000,
            callback=callback,
            progress_bar=True
        )
        model.save(f"{models_dir}simple_model_final")
        print(f"\nTraining Completed!")
        print(f"Total Episodes: {callback.total_episodes}")
        print(f"Vulnerabilities Found: {callback.vulnerability_count}")
        print(f"Success Rate: {callback.success_count / max(callback.total_episodes, 1):.2%}")
        print(f"Invalid Actions: {callback.invalid_action_count}")
        training_metrics = {
            'total_episodes': int(callback.total_episodes),
            'vulnerability_count': int(callback.vulnerability_count),
            'success_count': int(callback.success_count),
            'invalid_actions': int(callback.invalid_action_count),
            'training_completed': True
        }
        with open(f"{models_dir}training_metrics.json", 'w') as f:
            json.dump(training_metrics, f, indent=2)
    except Exception as e:
        print(f"Training error: {e}")
        model.save(f"{models_dir}simple_model_interrupted")
    env.close()
    return model
def test_single_episode():
    print("Single Episode Test")
    print("=" * 30)
    env = PentestEnv(target="test_single", simulator_mode=True)
    env = GymnasiumCompatibilityWrapper(env)
    obs, info = env.reset()
    print(f"Initial observation: {obs}")
    total_reward = 0
    for step in range(15):
        valid_actions = [i for i in range(8) if env.env._is_action_valid(i)]
        print(f"\nStep {step + 1}:")
        print(f"  Valid Actions: {valid_actions}")
        if valid_actions:
            action = valid_actions[0]
        else:
            action = 7
        print(f"  Taking Action: {action}")
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward
        print(f"  Reward: {reward:.2f} (Total: {total_reward:.2f})")
        print(f"  Done: {terminated}, Truncated: {truncated}")
        print(f"  Current State: {env.env.current_state}")
        if info.get('invalid_action'):
            print(f"  INVALID ACTION: {info.get('reason')}")
        if terminated or truncated:
            print(f"Episode ended after {step + 1} steps")
            break
    env.close()
class ProgressCallback(BaseCallback):
    def __init__(self, save_freq=10000, verbose=0):
        super().__init__(verbose)
        self.save_freq = save_freq
        self.episode_rewards = []
        self.episode_lengths = []
        self.total_episodes = 0
        self.vulnerability_count = 0
        self.success_count = 0
        self.invalid_action_count = 0
        self.best_success_rate = 0.0
        self.checkpoint_count = 0
    def _on_step(self) -> bool:
        for env_idx in range(self.training_env.num_envs):
            if self.locals.get('dones')[env_idx]:
                self.total_episodes += 1
                info = self.locals.get('infos')[env_idx]
                if info and 'episode' in info:
                    episode_reward = info['episode']['r']
                    episode_length = info['episode']['l']
                    self.episode_rewards.append(episode_reward)
                    self.episode_lengths.append(episode_length)
                    if episode_reward > 25:
                        self.vulnerability_count += 1
                        self.success_count += 1
                if info.get('invalid_action'):
                    self.invalid_action_count += 1
                if self.total_episodes % 500 == 0:
                    self._log_progress()
        if self.num_timesteps % self.save_freq == 0 and self.num_timesteps > 0:
            self._save_checkpoint()
        return True
    def _log_progress(self):
        if len(self.episode_rewards) >= 100:
            recent_rewards = self.episode_rewards[-100:]
            avg_reward = np.mean(recent_rewards)
            avg_length = np.mean(self.episode_lengths[-100:])
            success_rate = self.success_count / max(self.total_episodes, 1)
            recent_success = sum(1 for r in recent_rewards if r > 25) / len(recent_rewards)
            if recent_success > self.best_success_rate:
                self.best_success_rate = recent_success
            print(f"\nProgress Report - Episode {self.total_episodes}:")
            print(f"  Average Reward: {avg_reward:.2f}")
            print(f"  Average Length: {avg_length:.1f}")
            print(f"  Overall Success Rate: {success_rate:.2%}")
            print(f"  Recent Success Rate: {recent_success:.2%}")
            print(f"  Best Success Rate: {self.best_success_rate:.2%}")
            print(f"  Vulnerabilities Found: {self.vulnerability_count}")
            print(f"  Invalid Actions: {self.invalid_action_count}")
    def _save_checkpoint(self):
        self.checkpoint_count += 1
        models_dir = "./models/extended/"
        os.makedirs(models_dir, exist_ok=True)
        self.model.save(f"{models_dir}checkpoint_{self.checkpoint_count}_{self.num_timesteps}")
        print(f"\nCheckpoint saved: {self.checkpoint_count} at {self.num_timesteps} timesteps")
def create_extended_environment():
    def _init():
        env = PentestEnv(target="extended_training", simulator_mode=True)
        env = GymnasiumCompatibilityWrapper(env)
        env = ImprovedRewardWrapper(env)
        log_path = f"./logs/extended/{time.strftime('%Y-%m-%d_%H-%M-%S')}/"
        os.makedirs(log_path, exist_ok=True)
        return Monitor(env, log_path)
    return _init
def extended_training():
    print("Extended PPO Training for Pentesting Agent")
    print("=" * 50)
    print("Target: 10%+ success rate with 100K timesteps")
    print("This may take 5-10 minutes...")
    set_random_seed(42)
    torch.manual_seed(42)
    np.random.seed(42)
    env = DummyVecEnv([create_extended_environment()])
    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        learning_rate=5e-4,
        n_steps=512,
        batch_size=64,
        n_epochs=6,
        gamma=0.98,
        gae_lambda=0.95,
        clip_range=0.2,
        ent_coef=0.02,
        vf_coef=0.5,
        max_grad_norm=0.5,
        policy_kwargs=dict(
            net_arch=[128, 64],
            activation_fn=nn.ReLU
        ),
        tensorboard_log="./logs/extended/",
        device='cpu'
    )
def ultra_training():
    print("ULTRA PPO Training for Pentesting Agent")
    print("=" * 50)
    print("Target: 60%+ success rate with 250K timesteps")
    print("This may take 10-15 minutes...")
    set_random_seed(123)
    torch.manual_seed(123)
    np.random.seed(123)
    env = DummyVecEnv([create_ultra_environment() for _ in range(4)])
    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        learning_rate=3e-4,
        n_steps=1024,
        batch_size=128,
        n_epochs=8,
        gamma=0.99,
        gae_lambda=0.98,
        clip_range=0.15,
        ent_coef=0.005,
        vf_coef=0.5,
        max_grad_norm=0.5,
        policy_kwargs=dict(
            net_arch=[256, 128, 64],
            activation_fn=nn.ReLU
        ),
        tensorboard_log="./logs/ultra/",
        device='cpu'
    )
    callback = ProgressCallback(save_freq=25000, verbose=1)
    models_dir = "./models/extended/"
    os.makedirs(models_dir, exist_ok=True)
    print("Starting extended training...")
    try:
        model.learn(
            total_timesteps=100000,
            callback=callback,
            progress_bar=True
        )
        model.save(f"{models_dir}extended_model_final")
        print(f"\nExtended Training Completed!")
        print(f"Total Episodes: {callback.total_episodes}")
        print(f"Vulnerabilities Found: {callback.vulnerability_count}")
        print(f"Final Success Rate: {callback.success_count / max(callback.total_episodes, 1):.2%}")
        print(f"Best Success Rate Achieved: {callback.best_success_rate:.2%}")
        print(f"Invalid Actions: {callback.invalid_action_count}")
        training_metrics = {
            'total_episodes': int(callback.total_episodes),
            'vulnerability_count': int(callback.vulnerability_count),
            'success_count': int(callback.success_count),
            'best_success_rate': float(callback.best_success_rate),
            'invalid_actions': int(callback.invalid_action_count),
            'training_completed': True,
            'timesteps': 100000
        }
        with open(f"{models_dir}extended_metrics.json", 'w') as f:
            json.dump(training_metrics, f, indent=2)
        if callback.best_success_rate > 0.1:
            print("SUCCESS: Achieved >10% success rate!")
        elif callback.best_success_rate > 0.05:
            print("GOOD: Achieved >5% success rate!")
        else:
            print("PROGRESS: Model is learning but needs more training")
    except Exception as e:
        print(f"Training error: {e}")
        model.save(f"{models_dir}extended_model_interrupted")
    env.close()
    return model
def continue_training():
    print("Continue Training from Checkpoint")
    print("=" * 40)
    model_path = "./models/simple/simple_model_final.zip"
    if os.path.exists(model_path):
        print(f"Loading model: {model_path}")
        model = PPO.load(model_path)
        env = DummyVecEnv([create_extended_environment()])
        model.set_env(env)
        callback = ProgressCallback(save_freq=25000, verbose=1)
        print("Continuing training for additional 75,000 timesteps...")
        model.learn(
            total_timesteps=75000,
            callback=callback,
            progress_bar=True,
            reset_num_timesteps=False
        )
        models_dir = "./models/extended/"
        os.makedirs(models_dir, exist_ok=True)
        model.save(f"{models_dir}continued_model_final")
        print(f"\nContinued Training Completed!")
        print(f"Best Success Rate: {callback.best_success_rate:.2%}")
        env.close()
    else:
        print(f"Model not found: {model_path}")
        print("Run basic training first: python train.py train")
def main():
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        if command == "train":
            simple_training()
        elif command == "test":
            test_single_episode()
        elif command == "extended":
            extended_training()
        elif command == "ultra":
            ultra_training()
        elif command == "continue":
            continue_training()
        else:
            print("Available commands: train, test, extended, ultra, continue")
    else:
        print("PPO Pentest Agent Training")
        print("Available options:")
        print("  1. Simple Training (25K timesteps)")
        print("  2. Extended Training (100K timesteps)")
        print("  3. ULTRA Training (250K timesteps)")
        print("  4. Continue from Previous Model")
        print("  5. Single Episode Test")
        print("  6. Exit")
        choice = input("\nSelect option (1-6): ").strip()
        if choice == "1":
            simple_training()
        elif choice == "2":
            extended_training()
        elif choice == "3":
            ultra_training()
        elif choice == "4":
            continue_training()
        elif choice == "5":
            test_single_episode()
        elif choice == "6":
            print("Goodbye!")
        else:
            print("Invalid choice. Please select 1-6.")
if __name__ == "__main__":
    main()