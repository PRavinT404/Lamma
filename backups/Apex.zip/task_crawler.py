import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs, unquote
import time
import re
import json
from ai_core import ask_ollama_advanced, multi_stage_analysis, deep_response_analysis
import hashlib
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

class AdvancedCrawler:
    def __init__(self, base_url, session=None):
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()
        self.visited = set()
        self.attack_surface = []
        self.application_intelligence = {}
        self.technology_stack = {}
        self.security_mechanisms = {}
        
        # Advanced crawler settings
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
    
    def intelligent_path_discovery(self):
        """Discover paths using AI-driven wordlist generation"""
        
        # Analyze the main page first for context
        try:
            main_response = self.session.get(self.base_url, timeout=15)
            main_content = main_response.text
        except:
            main_content = ""
        
        path_analysis = ask_ollama_advanced(
            """Based on this web application, generate 25 likely directory/file paths that might exist.
            Consider the application type, technology stack, and common patterns.
            Think like a developer - what paths would they create?
            
            Respond with JSON: {"paths": ["path1", "path2", ...], "reasoning": "why these paths"}""",
            main_content[:5000],
            analysis_type="reconnaissance"
        )
        
        ai_paths = []
        if path_analysis and "paths" in path_analysis:
            ai_paths = [p.strip() for p in path_analysis["paths"] if p.strip()]
        
        return ai_paths
    
    def deep_form_analysis(self, form_element, page_url, page_context):
        """Perform deep analysis of forms for advanced attack vectors"""
        
        form_html = str(form_element)
        
        analysis_stages = {
            "form_purpose": {
                "prompt": "Analyze this HTML form and determine its business purpose, input validation patterns, and potential vulnerabilities. What is this form trying to accomplish?",
                "type": "vulnerability"
            },
            "attack_vectors": {
                "prompt": "Based on the form analysis, identify specific attack vectors. Consider injection points, business logic flaws, authentication bypasses, and privilege escalation opportunities.",
                "type": "vulnerability"  
            },
            "bypass_techniques": {
                "prompt": "Analyze potential input validation and security controls. How could an attacker bypass these mechanisms?",
                "type": "payload"
            }
        }
        
        context_data = f"""
        Form HTML: {form_html}
        Page URL: {page_url}
        Page Context: {page_context}
        """
        
        form_intelligence = multi_stage_analysis(context_data, analysis_stages)
        
        # Extract form details
        action = form_element.get("action") or page_url
        full_action = urljoin(page_url, action)
        method = form_element.get("method", "GET").upper()
        
        inputs = []
        for inp in form_element.find_all(["input", "textarea", "select"]):
            name = inp.get("name")
            input_type = inp.get("type", "text").lower()
            
            if name and input_type not in ["submit", "button", "reset"]:
                inputs.append({
                    "name": name,
                    "type": input_type,
                    "required": inp.has_attr("required"),
                    "placeholder": inp.get("placeholder", ""),
                    "value": inp.get("value", ""),
                    "maxlength": inp.get("maxlength"),
                    "pattern": inp.get("pattern")
                })
        
        return {
            "url": full_action,
            "method": method,
            "inputs": inputs,
            "form_html": form_html,
            "intelligence": form_intelligence,
            "csrf_protected": "csrf" in form_html.lower() or "_token" in form_html.lower()
        }
    
    def analyze_javascript_security(self, page_content, page_url):
        """Analyze JavaScript for client-side vulnerabilities"""
        
        js_analysis_prompt = """Analyze this JavaScript code for security vulnerabilities:
        1. DOM-based XSS opportunities
        2. Client-side authentication bypasses
        3. Sensitive information disclosure
        4. Unsafe functions (eval, innerHTML, etc.)
        5. AJAX endpoints and parameters
        6. Client-side routing vulnerabilities
        
        Respond with JSON: {"vulnerabilities": [list], "endpoints": [list], "sensitive_functions": [list]}"""
        
        soup = BeautifulSoup(page_content, 'html.parser')
        
        # Extract all JavaScript
        js_code = ""
        for script in soup.find_all('script'):
            if script.string:
                js_code += script.string + "\n"
        
        # Extract external JS files for analysis
        external_js = []
        for script in soup.find_all('script', src=True):
            src = script.get('src')
            if src:
                full_src = urljoin(page_url, src)
                external_js.append(full_src)
        
        if js_code.strip():
            js_analysis = ask_ollama_advanced(
                js_analysis_prompt,
                js_code[:10000],  # First 10KB of JS code
                analysis_type="vulnerability"
            )
        else:
            js_analysis = {"vulnerabilities": [], "endpoints": [], "sensitive_functions": []}
        
        return {
            "inline_analysis": js_analysis,
            "external_scripts": external_js,
            "total_js_size": len(js_code)
        }
    
    def crawl_with_intelligence(self, max_pages=50, delay=0.5):
        """Main crawling function with advanced intelligence gathering"""
        
        print(f"🕷️ Starting advanced intelligent crawling of: {self.base_url}")
        
        # Discover potential paths using AI
        potential_paths = self.intelligent_path_discovery()
        
        to_visit = [self.base_url] + [self.base_url + path for path in potential_paths]
        
        while to_visit and len(self.visited) < max_pages:
            url = to_visit.pop(0)
            
            if url in self.visited or not url.startswith(self.base_url):
                continue
            
            print(f"\n🔍 Deep analysis: {url}")
            self.visited.add(url)
            
            try:
                # First, check headers with a lightweight request
                head_response = self.session.head(url, timeout=10, allow_redirects=True)
                if head_response.status_code != 200:
                    print(f"   ⚠️ Skipping {url} (status code: {head_response.status_code})")
                    continue

                # If status is OK, then proceed with headless browser for full rendering
                options = Options()
                options.add_argument("--headless")
                options.add_argument("--no-sandbox")
                options.add_argument("--disable-dev-shm-usage")
                driver = None
                page_content = ""
                try:
                    driver = webdriver.Chrome(options=options)
                    driver.get(url)
                    time.sleep(2)  # Allow time for JS to render
                    page_content = driver.page_source
                finally:
                    if driver:
                        driver.quit()

                if not page_content:
                    print(f"   ❌ Failed to retrieve page content from {url} with Selenium.")
                    continue

                # Perform deep response analysis on the rendered content
                response_analysis = deep_response_analysis(
                    page_content, 
                    {"url": url, "status": 200, "headers": dict(head_response.headers)}
                )
                
                # Analyze JavaScript security
                js_analysis = self.analyze_javascript_security(page_content, url)
                
                soup = BeautifulSoup(page_content, "html.parser")

                # Find URL parameters used in JavaScript
                scripts = soup.find_all("script")
                js_params = set()
                for script in scripts:
                    if script.string:
                        found = re.findall(r"urlParams\.get\(['\"](.*?)['\"]\)", script.string)
                        for param in found:
                            js_params.add(param)
                
                if js_params:
                    print(f"   🔎 Found JS URL parameters: {list(js_params)}")
                    param_analysis = {
                        "url": url,
                        "method": "GET",
                        "inputs": [{"name": p, "type": "url_param"} for p in js_params],
                        "query_string": "",
                        "link_context": "Dynamically read from URL in JS",
                        "priority_score": len(js_params) * 10
                    }
                    self.attack_surface.append(param_analysis)
                
                # Deep form analysis
                forms = soup.find_all("form")
                if forms:
                    print(f"   📋 Analyzing {len(forms)} forms with AI...")
                    
                    for form in forms:
                        form_analysis = self.deep_form_analysis(
                            form, url, response_analysis
                        )
                        
                        if form_analysis["inputs"]:
                            # Calculate attack priority score
                            priority_score = self.calculate_attack_priority(form_analysis)
                            form_analysis["priority_score"] = priority_score
                            
                            self.attack_surface.append(form_analysis)
                            
                            print(f"   ✅ Form: {form_analysis['method']} {form_analysis['url']} (Priority: {priority_score})")
                
                # Find parameterized URLs
                for a in soup.find_all("a", href=True):
                    href = a["href"]
                    full_url = urljoin(url, href)
                    
                    parsed = urlparse(full_url)
                    if parsed.query:
                        params = list(parse_qs(parsed.query).keys())
                        if params:
                            param_analysis = {
                                "url": full_url.split('?')[0],
                                "method": "GET",
                                "inputs": [{"name": p, "type": "url_param"} for p in params],
                                "query_string": parsed.query,
                                "link_context": a.get_text(strip=True)[:100],
                                "priority_score": len(params) * 2  # Simple scoring
                            }
                            self.attack_surface.append(param_analysis)
                            print(f"   🔗 URL params: {full_url.split('?')[0]} -> {params}")
                    
                    # Add to crawl queue
                    if (full_url.startswith(self.base_url) and 
                        full_url not in self.visited and 
                        len(self.visited) + len(to_visit) < max_pages):
                        to_visit.append(full_url)
                
                time.sleep(delay)
                
            except Exception as e:
                print(f"   ❌ Error crawling {url}: {e}")
                continue
        
        # Sort attack surface by priority
        self.attack_surface.sort(key=lambda x: x.get("priority_score", 0), reverse=True)
        
        print(f"\n🎯 Advanced crawling complete:")
        print(f"   📄 Pages analyzed: {len(self.visited)}")
        print(f"   🎯 Attack targets found: {len(self.attack_surface)}")
        print(f"   🥇 Top priority targets:")
        
        for i, target in enumerate(self.attack_surface[:5], 1):
            print(f"   {i}. {target['method']} {target['url']} (Score: {target.get('priority_score', 0)})")
        
        return self.attack_surface
    
    def calculate_attack_priority(self, target):
        """Calculate attack priority based on multiple factors"""
        score = 0
        
        # Input-based scoring
        for inp in target.get("inputs", []):
            if inp.get("type") == "search" or "search" in inp.get("name", "").lower():
                score += 15
            elif inp.get("type") in ["text", "textarea"]:
                score += 10
            elif inp.get("type") == "hidden":
                score += 5
        
        # Intelligence-based scoring
        intelligence = target.get("intelligence", {})
        
        if intelligence.get("attack_vectors", {}).get("vulnerabilities"):
            score += len(intelligence["attack_vectors"]["vulnerabilities"]) * 5
        
        # CSRF protection reduces priority slightly (harder to exploit)
        if target.get("csrf_protected"):
            score -= 2
        
        # Method-based scoring
        if target.get("method") == "POST":
            score += 3
        
        return max(score, 1)  # Minimum score of 1

def crawl_site(base_url, session=None, max_pages=50, delay=0.5):
    """Enhanced crawl_site function for backward compatibility"""
    try:
        crawler = AdvancedCrawler(base_url, session)
        attack_surface = crawler.crawl_with_intelligence(max_pages, delay)
        
        # Convert to format expected by existing code
        formatted_targets = []
        for target in attack_surface:
            formatted_target = {
                "url": target["url"],
                "method": target.get("method", "GET"),
                "params": [inp["name"] for inp in target.get("inputs", [])],
                "input_contexts": target.get("inputs", []),
                "intelligence": target.get("intelligence", {}),
                "priority_score": target.get("priority_score", 1),
                "advanced_analysis": True
            }
            formatted_targets.append(formatted_target)
        
        return formatted_targets
    except requests.exceptions.RequestException as e:
        print(f"Error during crawling: {e}")
        return []